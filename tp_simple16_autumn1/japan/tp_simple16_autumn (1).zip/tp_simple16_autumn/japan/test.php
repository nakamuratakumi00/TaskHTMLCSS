<?php
$date = $_GET['date'];
echo $date;

$japan = $_GET['japan'];
echo $japan;

$Prefecture = $_GET['Prefecture'];
echo $Prefecture;
