<?php
$Date = $_GET['date'];
$date = array((string)$Date);
$date1=(string)$Date[0];
$date2=(string)$Date[1];

$Prefecture = $_GET['Prefecture'];
$prefecture = array((string)$Prefecture);

$Japan = $_GET['japan'];
$japan = array((string)$Japan);

//echo $date;
//echo $japan;

//echo "aaa";

//$date = array('date' => '2019/01/01');
//$japan = array('japan' => 'toukyou');
//$prefecture = array('prefecture' => 'toukyou');

$link = mysqli_connect('localhost', 'root', '', 'test2');


// 接続状況をチェック
if (mysqli_connect_errno()) {
  die("データベースに接続できません:" . mysqli_connect_error() . "\n");
}

echo "データベースの接続に成功しました。<br />";
/*  */
// DB接続情報
/* $dsn = 'mysql:host=localhost;dbname=test2;charset=utf8mb4';
$username = 'root';
$password = '';


try {

  // PDOインスタンスを生成
  $dbh = new PDO($dsn, $username);

  // エラー（例外）が発生した時の処理を記述
} catch (PDOException $e) {

  // エラーメッセージを表示させる
  echo 'データベースにアクセスできません！' . $e->getMessage();

  // 強制終了
  exit;
} */


$sql = "select * from weather where prefecture='" . $prefecture[0] . "' AND district = '" . $japan[0] . "' AND date BETWEEN '" . $date1 . "' and '".$date2."'";
$stmt = $link->query($sql);
foreach ($stmt as $row) {

  echo $row['date'] . $row['noon_weather'] . $row['night_weather'];
}
